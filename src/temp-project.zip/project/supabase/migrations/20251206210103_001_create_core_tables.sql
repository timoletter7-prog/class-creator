/*
  # Create core tables for DigiBalans

  1. New Tables
    - `class_groups` - Store teacher classes/groups
    - `student_profiles` - Store student information
    - `daily_stats` - Track daily student statistics
    - `user_settings` - Store user preferences and limits
    - `app_management` - Store whitelisted/blacklisted apps

  2. Security
    - Enable RLS on all tables
    - Teachers can manage their own classes
    - Students can only view their own data
    - Settings are per-user
*/

-- class_groups table
CREATE TABLE IF NOT EXISTS class_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  school_year TEXT DEFAULT '2024-2025',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE class_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teachers can view own classes"
  ON class_groups FOR SELECT
  TO authenticated
  USING (teacher_id = auth.uid());

CREATE POLICY "Teachers can create classes"
  ON class_groups FOR INSERT
  TO authenticated
  WITH CHECK (teacher_id = auth.uid());

CREATE POLICY "Teachers can update own classes"
  ON class_groups FOR UPDATE
  TO authenticated
  USING (teacher_id = auth.uid())
  WITH CHECK (teacher_id = auth.uid());

CREATE POLICY "Teachers can delete own classes"
  ON class_groups FOR DELETE
  TO authenticated
  USING (teacher_id = auth.uid());

-- student_profiles table
CREATE TABLE IF NOT EXISTS student_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_group_id UUID NOT NULL REFERENCES class_groups(id) ON DELETE CASCADE,
  user_email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  points NUMERIC DEFAULT 10,
  streak_days INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'blocked', 'warning')),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE student_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view own profile"
  ON student_profiles FOR SELECT
  TO authenticated
  USING (user_email = auth.jwt()->>'email');

CREATE POLICY "Teachers can view class students"
  ON student_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM class_groups
      WHERE class_groups.id = student_profiles.class_group_id
      AND class_groups.teacher_id = auth.uid()
    )
  );

CREATE POLICY "Teachers can create student profiles"
  ON student_profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM class_groups
      WHERE class_groups.id = class_group_id
      AND class_groups.teacher_id = auth.uid()
    )
  );

-- daily_stats table
CREATE TABLE IF NOT EXISTS daily_stats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES student_profiles(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  screen_time_minutes INTEGER DEFAULT 0,
  violations_count INTEGER DEFAULT 0,
  points_change NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(student_id, date)
);

ALTER TABLE daily_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Students can view own stats"
  ON daily_stats FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM student_profiles
      WHERE student_profiles.id = daily_stats.student_id
      AND student_profiles.user_email = auth.jwt()->>'email'
    )
  );

CREATE POLICY "Teachers can view class stats"
  ON daily_stats FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM student_profiles
      JOIN class_groups ON class_groups.id = student_profiles.class_group_id
      WHERE student_profiles.id = daily_stats.student_id
      AND class_groups.teacher_id = auth.uid()
    )
  );

-- user_settings table
CREATE TABLE IF NOT EXISTS user_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  daily_limit_minutes INTEGER DEFAULT 120,
  weekend_mode BOOLEAN DEFAULT true,
  strict_mode BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own settings"
  ON user_settings FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- app_management table
CREATE TABLE IF NOT EXISTS app_management (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_group_id UUID NOT NULL REFERENCES class_groups(id) ON DELETE CASCADE,
  app_name TEXT NOT NULL,
  app_type TEXT NOT NULL CHECK (app_type IN ('whitelisted', 'blacklisted')),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(class_group_id, app_name, app_type)
);

ALTER TABLE app_management ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Teachers can manage apps for their classes"
  ON app_management FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM class_groups
      WHERE class_groups.id = app_management.class_group_id
      AND class_groups.teacher_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS idx_class_groups_teacher ON class_groups(teacher_id);
CREATE INDEX IF NOT EXISTS idx_student_profiles_class ON student_profiles(class_group_id);
CREATE INDEX IF NOT EXISTS idx_daily_stats_student_date ON daily_stats(student_id, date);
CREATE INDEX IF NOT EXISTS idx_app_management_class ON app_management(class_group_id);
