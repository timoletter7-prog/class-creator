const API_BASE = import.meta.env.VITE_SUPABASE_URL || '';
const API_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

class Base44Client {
  constructor() {
    this.entities = {
      ClassGroup: this.createEntityAPI('ClassGroup'),
      StudentProfile: this.createEntityAPI('StudentProfile'),
      DailyStat: this.createEntityAPI('DailyStat'),
    };

    this.auth = {
      me: async () => {
        return { email: 'demo@school.nl', full_name: 'Demo Gebruiker' };
      },
      logout: async () => {
        console.log('Logout');
      }
    };
  }

  createEntityAPI(entityName) {
    const tableName = this.toSnakeCase(entityName);

    return {
      list: async () => {
        try {
          const response = await fetch(`${API_BASE}/rest/v1/${tableName}?select=*`, {
            headers: {
              'apikey': API_KEY,
              'Authorization': `Bearer ${API_KEY}`,
            },
          });
          if (!response.ok) return [];
          return await response.json();
        } catch (error) {
          console.error(`Error listing ${entityName}:`, error);
          return [];
        }
      },

      get: async (id) => {
        try {
          const response = await fetch(`${API_BASE}/rest/v1/${tableName}?id=eq.${id}`, {
            headers: {
              'apikey': API_KEY,
              'Authorization': `Bearer ${API_KEY}`,
            },
          });
          if (!response.ok) return null;
          const data = await response.json();
          return data[0] || null;
        } catch (error) {
          console.error(`Error getting ${entityName}:`, error);
          return null;
        }
      },

      create: async (data) => {
        try {
          const response = await fetch(`${API_BASE}/rest/v1/${tableName}`, {
            method: 'POST',
            headers: {
              'apikey': API_KEY,
              'Authorization': `Bearer ${API_KEY}`,
              'Content-Type': 'application/json',
              'Prefer': 'return=representation',
            },
            body: JSON.stringify(data),
          });
          if (!response.ok) throw new Error('Failed to create');
          const result = await response.json();
          return result[0];
        } catch (error) {
          console.error(`Error creating ${entityName}:`, error);
          throw error;
        }
      },

      update: async (id, data) => {
        try {
          const response = await fetch(`${API_BASE}/rest/v1/${tableName}?id=eq.${id}`, {
            method: 'PATCH',
            headers: {
              'apikey': API_KEY,
              'Authorization': `Bearer ${API_KEY}`,
              'Content-Type': 'application/json',
              'Prefer': 'return=representation',
            },
            body: JSON.stringify(data),
          });
          if (!response.ok) throw new Error('Failed to update');
          const result = await response.json();
          return result[0];
        } catch (error) {
          console.error(`Error updating ${entityName}:`, error);
          throw error;
        }
      },

      delete: async (id) => {
        try {
          const response = await fetch(`${API_BASE}/rest/v1/${tableName}?id=eq.${id}`, {
            method: 'DELETE',
            headers: {
              'apikey': API_KEY,
              'Authorization': `Bearer ${API_KEY}`,
            },
          });
          if (!response.ok) throw new Error('Failed to delete');
          return true;
        } catch (error) {
          console.error(`Error deleting ${entityName}:`, error);
          throw error;
        }
      },
    };
  }

  toSnakeCase(str) {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`).replace(/^_/, '');
  }
}

export const base44 = new Base44Client();
