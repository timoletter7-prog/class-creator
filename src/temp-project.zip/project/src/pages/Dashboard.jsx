import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../contexts/AuthContext';
import TeacherDashboard from '../components/dashboard/TeacherDashboard';
import StudentDashboard from '../components/dashboard/StudentDashboard';
import { Button } from "@/components/ui/button";
import { RotateCw } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, viewMode, setViewMode } = useAuth();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const queryClient = useQueryClient();

  const { data: classes = [] } = useQuery({
    queryKey: ['classes', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from('class_groups')
        .select('*')
        .eq('teacher_id', user.id);
      if (error) {
        console.error('Error fetching classes:', error);
        return [];
      }
      return data || [];
    },
    enabled: !!user?.id,
  });

  const { data: myStudentProfile } = useQuery({
    queryKey: ['myStudentProfile', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const { data, error } = await supabase
        .from('student_profiles')
        .select('*')
        .eq('user_email', user.email)
        .maybeSingle();
      if (error) {
        console.error('Error fetching student profile:', error);
        return null;
      }
      return data;
    },
    enabled: !!user?.email,
  });

const createClassMutation = useMutation({
  mutationFn: async (data) => {
    const { error, data: createdClasses } = await supabase
      .from('class_groups')
      .insert([
        {
          teacher_id: user.id,
          name: data.name,
          description: data.description,
        }
      ])
      .select();

    if (error) throw error;
    return createdClasses[0]; // eerste klas teruggeven
  },
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['classes', user?.id] });
    setIsCreateModalOpen(false);
    setNewClassName('');
    toast.success('Klas aangemaakt!');
  },
  onError: (error) => {
    toast.error('Fout bij het aanmaken van de klas: ' + error.message);
  }
});


  const handleCreateClass = () => {
    if (!newClassName.trim()) {
      toast.error('Voer een klasnaam in');
      return;
    }
    createClassMutation.mutate({
      name: newClassName,
      description: `Aangemaakt op ${new Date().toLocaleDateString('nl-NL')}`,
    });
  };

  return (
    <div className="relative">
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setViewMode(viewMode === 'teacher' ? 'student' : 'teacher')}
          className="shadow-xl rounded-full h-12 px-6 bg-slate-900 hover:bg-slate-800 text-white transition-all duration-300"
        >
          <RotateCw className="w-4 h-4 mr-2" />
          Wissel naar {viewMode === 'teacher' ? 'Student' : 'Docent'} View
        </Button>
      </div>

      {viewMode === 'teacher' ? (
        <TeacherDashboard
          classes={classes}
          onAddClass={() => setIsCreateModalOpen(true)}
        />
      ) : (
        <StudentDashboard
          profile={myStudentProfile || {
            full_name: user?.user_metadata?.full_name || 'Student',
            points: 10,
            streak_days: 0
          }}
        />
      )}

      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nieuwe Klasgroep</DialogTitle>
            <DialogDescription>
              Maak een nieuwe klas aan om studenten te beheren en hun digitale welzijn te monitoren.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Naam van de klas</Label>
              <Input
                id="name"
                placeholder="bijv. Groep 8A - 2024"
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Annuleren</Button>
            <Button onClick={handleCreateClass} className="bg-indigo-600 text-white">Aanmaken</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
