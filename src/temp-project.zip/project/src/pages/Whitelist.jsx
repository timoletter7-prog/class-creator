import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus } from "lucide-react";
import { toast } from "sonner";

export default function Whitelist() {
  const { user } = useAuth();
  const [selectedClassId, setSelectedClassId] = useState(null);
  const [newAppName, setNewAppName] = useState('');
  const [appType, setAppType] = useState('whitelisted');
  const queryClient = useQueryClient();

  const { data: classes = [] } = useQuery({
    queryKey: ['classes', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from('class_groups')
        .select('*')
        .eq('teacher_id', user.id);
      if (error) {
        console.error('Error fetching classes:', error);
        return [];
      }
      return data || [];
    },
    enabled: !!user?.id,
  });

  const { data: apps = [] } = useQuery({
    queryKey: ['apps', selectedClassId],
    queryFn: async () => {
      if (!selectedClassId) return [];
      const { data, error } = await supabase
        .from('app_management')
        .select('*')
        .eq('class_group_id', selectedClassId);
      if (error) {
        console.error('Error fetching apps:', error);
        return [];
      }
      return data || [];
    },
    enabled: !!selectedClassId,
  });

  const whitelistedApps = apps.filter(a => a.app_type === 'whitelisted');
  const blacklistedApps = apps.filter(a => a.app_type === 'blacklisted');

  const addAppMutation = useMutation({
    mutationFn: async (newApp) => {
      const { error } = await supabase
        .from('app_management')
        .insert([
          {
            class_group_id: selectedClassId,
            app_name: newApp.name,
            app_type: newApp.type,
          }
        ]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['apps', selectedClassId] });
      setNewAppName('');
      toast.success('App toegevoegd!');
    },
    onError: (error) => {
      toast.error('Fout: ' + error.message);
    }
  });

  const deleteAppMutation = useMutation({
    mutationFn: async (appId) => {
      const { error } = await supabase
        .from('app_management')
        .delete()
        .eq('id', appId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['apps', selectedClassId] });
      toast.success('App verwijderd!');
    },
    onError: (error) => {
      toast.error('Fout: ' + error.message);
    }
  });

  const handleAddApp = () => {
    if (!newAppName.trim()) {
      toast.error('Voer een app naam in');
      return;
    }
    if (!selectedClassId) {
      toast.error('Selecteer eerst een klas');
      return;
    }
    addAppMutation.mutate({ name: newAppName, type: appType });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">App Beheer</h1>
        <p className="text-slate-500 mt-2">Beheer welke apps studenten mogen gebruiken</p>
      </div>

      {/* Class Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Selecteer een klas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
            {classes.length > 0 ? (
              classes.map((cls) => (
                <Button
                  key={cls.id}
                  variant={selectedClassId === cls.id ? 'default' : 'outline'}
                  onClick={() => setSelectedClassId(cls.id)}
                  className="text-left"
                >
                  {cls.name}
                </Button>
              ))
            ) : (
              <p className="text-slate-500">Geen klassen beschikbaar</p>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedClassId && (
        <>
          {/* Add App Form */}
          <Card>
            <CardHeader>
              <CardTitle>App toevoegen</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="app-name">App naam</Label>
                <Input
                  id="app-name"
                  placeholder="bijv. YouTube, Discord"
                  value={newAppName}
                  onChange={(e) => setNewAppName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="app-type">Type</Label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="whitelisted"
                      checked={appType === 'whitelisted'}
                      onChange={(e) => setAppType(e.target.value)}
                    />
                    <span>Toegestaan</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="blacklisted"
                      checked={appType === 'blacklisted'}
                      onChange={(e) => setAppType(e.target.value)}
                    />
                    <span>Geblokkeerd</span>
                  </label>
                </div>
              </div>
              <Button onClick={handleAddApp} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Toevoegen
              </Button>
            </CardContent>
          </Card>

          {/* Apps List */}
          <Tabs defaultValue="whitelisted" className="w-full">
            <TabsList>
              <TabsTrigger value="whitelisted">Toegestaan ({whitelistedApps.length})</TabsTrigger>
              <TabsTrigger value="blacklisted">Geblokkeerd ({blacklistedApps.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="whitelisted">
              <Card>
                <CardContent className="pt-6">
                  {whitelistedApps.length > 0 ? (
                    <div className="space-y-2">
                      {whitelistedApps.map((app) => (
                        <div
                          key={app.id}
                          className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200"
                        >
                          <div>
                            <p className="font-medium text-green-900">{app.app_name}</p>
                            <Badge className="mt-1">Toegestaan</Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteAppMutation.mutate(app.id)}
                            className="text-red-600 hover:text-red-800 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-center py-8">Geen toegestane apps</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="blacklisted">
              <Card>
                <CardContent className="pt-6">
                  {blacklistedApps.length > 0 ? (
                    <div className="space-y-2">
                      {blacklistedApps.map((app) => (
                        <div
                          key={app.id}
                          className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200"
                        >
                          <div>
                            <p className="font-medium text-red-900">{app.app_name}</p>
                            <Badge variant="destructive" className="mt-1">Geblokkeerd</Badge>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteAppMutation.mutate(app.id)}
                            className="text-red-600 hover:text-red-800 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-center py-8">Geen geblokkeerde apps</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}
