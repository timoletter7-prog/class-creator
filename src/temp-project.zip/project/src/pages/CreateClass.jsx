import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function CreateClass({ onCreate }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const newClass = {
      id: Date.now(),
      name,
      description,
      student_count: 0,
    };

    // 🔎 Debug logs
    console.log("CreateClass: submitting new class", newClass);

    onCreate(newClass);

    // feedback via toast
    toast.success(`Klas "${name}" aangemaakt!`);

    navigate("/"); // terug naar dashboard
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold">Nieuwe klas aanmaken</h2>
      <div>
        <label className="block text-sm font-medium">Naam van de klas</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border rounded p-2 w-full"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium">Beschrijving</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="border rounded p-2 w-full"
        />
      </div>
      <div className="flex gap-2">
        <Button type="submit" className="bg-indigo-600 text-white">
          Opslaan
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate("/")}
        >
          Annuleren
        </Button>
      </div>
    </form>
  );
}
