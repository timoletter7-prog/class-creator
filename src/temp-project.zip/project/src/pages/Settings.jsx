import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Smartphone, CalendarClock, ShieldCheck, Save } from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [dailyLimit, setDailyLimit] = useState([120]);
  const [weekendMode, setWeekendMode] = useState(true);
  const [strictMode, setStrictMode] = useState(false);

  const { data: settings } = useQuery({
    queryKey: ['userSettings', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      if (error) {
        console.error('Error fetching settings:', error);
        return null;
      }
      return data;
    },
    enabled: !!user?.id,
  });

  useEffect(() => {
    if (settings) {
      setDailyLimit([settings.daily_limit_minutes]);
      setWeekendMode(settings.weekend_mode);
      setStrictMode(settings.strict_mode);
    }
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error('No user');

      if (settings?.id) {
        const { error } = await supabase
          .from('user_settings')
          .update({
            daily_limit_minutes: dailyLimit[0],
            weekend_mode: weekendMode,
            strict_mode: strictMode,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('user_settings')
          .insert([
            {
              user_id: user.id,
              daily_limit_minutes: dailyLimit[0],
              weekend_mode: weekendMode,
              strict_mode: strictMode,
            }
          ]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userSettings', user?.id] });
      toast.success('Instellingen opgeslagen!');
    },
    onError: (error) => {
      toast.error('Fout: ' + error.message);
    }
  });

  const formatTime = (minutes) => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${h}u ${m}m`;
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Instellingen</h1>
        <p className="text-slate-500">Beheer je limieten en voorkeuren.</p>
      </div>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-600" />
            Schermtijd Limieten
          </CardTitle>
          <CardDescription>Bepaal hoeveel tijd je per dag aan 'entertainment' apps mag besteden.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-base font-medium">Dagelijkse Limiet</Label>
              <span className="text-indigo-600 font-bold bg-indigo-50 px-3 py-1 rounded-md">
                {formatTime(dailyLimit[0])}
              </span>
            </div>
            <Slider
              value={dailyLimit}
              onValueChange={setDailyLimit}
              max={240}
              min={30}
              step={15}
              className="py-4"
            />
            <p className="text-sm text-slate-500">
              Aanbevolen: Maximaal 2 uur per dag voor een gezonde balans.
            </p>
          </div>

          <div className="flex items-center justify-between space-x-4 pt-4 border-t border-slate-100">
            <div className="flex flex-col space-y-1">
              <Label htmlFor="weekend-mode" className="text-base font-medium flex items-center gap-2">
                <CalendarClock className="w-4 h-4 text-slate-500" />
                Vrij Weekend
              </Label>
              <span className="text-sm text-slate-500">
                Geen strikte limieten op zaterdag en zondag.
              </span>
            </div>
            <Switch
              id="weekend-mode"
              checked={weekendMode}
              onCheckedChange={setWeekendMode}
            />
          </div>

          <div className="flex items-center justify-between space-x-4 pt-4 border-t border-slate-100">
            <div className="flex flex-col space-y-1">
              <Label htmlFor="strict-mode" className="text-base font-medium flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-slate-500" />
                Strenge Modus (Hard Block)
              </Label>
              <span className="text-sm text-slate-500">
                Apps sluiten direct af als de tijd op is. Kan niet worden genegeerd.
              </span>
            </div>
            <Switch
              id="strict-mode"
              checked={strictMode}
              onCheckedChange={setStrictMode}
            />
          </div>
        </CardContent>
        <CardFooter className="bg-slate-50 border-t border-slate-100 flex justify-end p-4">
          <Button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            className="bg-indigo-600 hover:bg-indigo-700 text-white"
          >
            <Save className="w-4 h-4 mr-2" />
            {saveMutation.isPending ? 'Bezig...' : 'Opslaan'}
          </Button>
        </CardFooter>
      </Card>

      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle>Privacy & Gegevens</CardTitle>
          <CardDescription>Wat wordt er gedeeld met de docent?</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-slate-600">
          <p>• <strong>Zichtbaar:</strong> Totale schermtijd tijdens schooluren (08:30 - 15:00), aantal blokkades.</p>
          <p>• <strong>Niet Zichtbaar:</strong> Inhoud van berichten, foto's, specifieke websites bezocht buiten de whitelist apps.</p>
          <div className="mt-4 bg-blue-50 p-3 rounded-lg border border-blue-100 text-blue-700 text-xs">
            Wij voldoen aan de AVG (GDPR). Je gegevens worden nooit verkocht aan derden.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
