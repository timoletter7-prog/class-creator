import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, ArrowRight, Plus, GraduationCap, Shield, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "sonner";

export default function Classes() {
  const queryClient = useQueryClient();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const [newClassName, setNewClassName] = useState('');
  const [newApp, setNewApp] = useState('');

  const { data: classes, isLoading } = useQuery({
    queryKey: ['classes'],
    queryFn: () => base44.entities.ClassGroup.list(),
  });

  // Fetch students for selected class (in a real app this would filter on backend)
  const { data: allStudents } = useQuery({
    queryKey: ['students'],
    queryFn: () => base44.entities.StudentProfile.list(),
  });
  
  const classStudents = allStudents?.filter(s => s.class_group_id === selectedClass?.id) || [];

  const createClassMutation = useMutation({
    mutationFn: (data) => base44.entities.ClassGroup.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['classes']);
      setIsCreateOpen(false);
      setNewClassName('');
      toast.success("Klas aangemaakt!");
    },
  });

  const updateClassMutation = useMutation({
    mutationFn: (data) => base44.entities.ClassGroup.update(selectedClass.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['classes']);
      toast.success("Wijzigingen opgeslagen");
    },
  });

  const handleCreate = () => {
    if (!newClassName) return;
    createClassMutation.mutate({
      name: newClassName,
      school_year: '2023-2024',
      description: 'Nieuwe klasgroep',
      whitelisted_apps: ["Rekenmachine", "SchoolPortaal", "Wikipedia"]
    });
  };

  const handleAddApp = () => {
    if (!newApp) return;
    const currentApps = selectedClass.whitelisted_apps || [];
    // Case insensitive check
    if (currentApps.some(app => app.toLowerCase() === newApp.toLowerCase())) {
        toast.error("App bestaat al");
        return;
    }
    
    const updatedApps = [...currentApps, newApp];
    updateClassMutation.mutate({ whitelisted_apps: updatedApps });
    // Optimistically update local state for UI responsiveness
    setSelectedClass({...selectedClass, whitelisted_apps: updatedApps});
    setNewApp('');
  };

  const handleRemoveApp = (appToRemove) => {
    const currentApps = selectedClass.whitelisted_apps || [];
    const updatedApps = currentApps.filter(app => app !== appToRemove);
    updateClassMutation.mutate({ whitelisted_apps: updatedApps });
    // Optimistically update local state
    setSelectedClass({...selectedClass, whitelisted_apps: updatedApps});
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Mijn Klassen</h1>
          <p className="text-slate-500">Beheer je klasgroepen en studenten.</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)} className="bg-indigo-600 hover:bg-indigo-700 text-white">
          <Plus className="w-4 h-4 mr-2" />
          Nieuwe Klas
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {[1, 2, 3].map(i => (
             <div key={i} className="h-48 bg-slate-100 rounded-xl animate-pulse"></div>
           ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classes?.map((group) => (
            <Card 
              key={group.id} 
              className="hover:shadow-md transition-all group cursor-pointer border-slate-200 flex flex-col"
              onClick={() => setSelectedClass(group)}
            >
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600 mb-2">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <Badge variant="outline" className="bg-slate-50">
                    {group.school_year}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{group.name}</CardTitle>
                <CardDescription>{group.description || 'Geen beschrijving'}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="flex items-center gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {/* Only visual count since we fetch all students separately */}
                    <span>Leerlingen beheren</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Shield className="w-4 h-4" />
                    <span>Whitelist: {group.whitelisted_apps?.length || 0} apps</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t border-slate-100 pt-4 mt-auto">
                <Button variant="ghost" className="w-full group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors flex justify-between items-center">
                  Beheer Klas
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
              </CardFooter>
            </Card>
          ))}
          
          {/* Add New Card Placeholder */}
          <button 
            onClick={() => setIsCreateOpen(true)}
            className="border-2 border-dashed border-slate-200 rounded-xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:text-indigo-500 hover:bg-indigo-50/50 transition-all min-h-[250px]"
          >
            <div className="p-3 rounded-full bg-slate-50 mb-3 group-hover:bg-white">
              <Plus className="w-6 h-6" />
            </div>
            <span className="font-medium">Nieuwe Klas Toevoegen</span>
          </button>
        </div>
      )}

      {/* Create Modal */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nieuwe Klas Aanmaken</DialogTitle>
            <DialogDescription>Geef de klas een naam om te beginnen.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Input 
              placeholder="Naam van de klas (bijv. Groep 7)" 
              value={newClassName}
              onChange={(e) => setNewClassName(e.target.value)}
            />
          </div>
          <DialogFooter>
             <Button variant="outline" onClick={() => setIsCreateOpen(false)}>Annuleren</Button>
             <Button onClick={handleCreate} className="bg-indigo-600 text-white">Aanmaken</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Details & Manage Modal */}
      <Dialog open={!!selectedClass} onOpenChange={(open) => !open && setSelectedClass(null)}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedClass?.name} Beheren</DialogTitle>
            <DialogDescription>Beheer studenten en app-whitelists.</DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="students" className="w-full mt-4">
            <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent space-x-6">
              <TabsTrigger 
                value="students" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-indigo-600 data-[state=active]:bg-transparent px-0 py-2"
              >
                Studenten
              </TabsTrigger>
              <TabsTrigger 
                value="whitelist" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-indigo-600 data-[state=active]:bg-transparent px-0 py-2"
              >
                App Whitelist
              </TabsTrigger>
            </TabsList>

            <TabsContent value="students" className="pt-4 min-h-[300px]">
               <div className="space-y-3">
                 {classStudents.length > 0 ? (
                   classStudents.map(student => (
                     <div key={student.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                       <div className="flex items-center gap-3">
                         <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-700 font-bold text-sm">
                           {student.full_name.charAt(0)}
                         </div>
                         <div>
                           <p className="font-medium text-slate-900">{student.full_name}</p>
                           <p className="text-xs text-slate-500">{student.points} punten</p>
                         </div>
                       </div>
                       <Badge variant={student.points < 10 ? 'destructive' : 'outline'} className={student.points >= 10 ? "bg-white" : ""}>
                         {student.points < 10 ? 'Aandacht' : 'Actief'}
                       </Badge>
                     </div>
                   ))
                 ) : (
                   <div className="text-center py-12">
                     <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                     <p className="text-slate-500">Geen studenten gevonden in deze klas.</p>
                   </div>
                 )}
               </div>
            </TabsContent>

            <TabsContent value="whitelist" className="pt-4 min-h-[300px]">
               <div className="space-y-6">
                 <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800 flex gap-3 items-start">
                   <Shield className="w-5 h-5 flex-shrink-0 mt-0.5" />
                   <div>
                     <p className="font-semibold mb-1">Whitelist Systeem</p>
                     <p>Apps in deze lijst zijn altijd toegestaan tijdens schooluren. Alle andere apps worden geblokkeerd.</p>
                   </div>
                 </div>

                 <div className="flex gap-2">
                   <Input 
                     placeholder="App naam toevoegen (bijv. Duolingo)" 
                     value={newApp}
                     onChange={(e) => setNewApp(e.target.value)}
                     onKeyDown={(e) => e.key === 'Enter' && handleAddApp()}
                   />
                   <Button onClick={handleAddApp} variant="secondary">Toevoegen</Button>
                 </div>

                 <div className="flex flex-wrap gap-2">
                   {selectedClass?.whitelisted_apps?.map((app) => (
                     <Badge key={app} variant="secondary" className="pl-3 pr-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm flex items-center gap-2 transition-colors">
                       {app}
                       <button 
                         onClick={() => handleRemoveApp(app)}
                         className="hover:bg-slate-300 hover:text-red-600 rounded-full p-0.5 transition-all"
                       >
                         <Trash2 className="w-3 h-3" />
                       </button>
                     </Badge>
                   ))}
                   {(!selectedClass?.whitelisted_apps || selectedClass.whitelisted_apps.length === 0) && (
                     <p className="text-slate-500 text-sm italic w-full text-center py-4">Nog geen apps op de whitelist.</p>
                   )}
                 </div>
               </div>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
