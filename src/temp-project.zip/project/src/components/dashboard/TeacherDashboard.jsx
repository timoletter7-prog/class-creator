import React, { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import StatCard from "./StatCard";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Zap, Clock, Plus } from "lucide-react";
import { toast } from "sonner";

export default function TeacherDashboard({ user }) {
  const queryClient = useQueryClient();
  const [creating, setCreating] = useState(false);

  // Klassen ophalen
  const { data: classes = [], isLoading } = useQuery({
    queryKey: ["classes", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from("class_groups")
        .select("*")
        .eq("teacher_id", user.id);
      if (error) {
        console.error("Error fetching classes:", error);
        return [];
      }
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Nieuwe klas aanmaken
  const createClassMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("class_groups")
        .insert([
          {
            teacher_id: user.id,
            name: `Nieuwe klas ${new Date().toLocaleTimeString("nl-NL")}`,
            description: `Aangemaakt op ${new Date().toLocaleDateString("nl-NL")}`,
          },
        ])
        .select(); // geen .single()
      if (error) throw error;
      return data[0];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["classes", user?.id] });
      setCreating(false);
      toast.success("Klas aangemaakt!");
    },
    onError: (error) => {
      toast.error("Fout bij het aanmaken van de klas: " + error.message);
    },
  });

  const stats = [
    {
      title: "Actieve Klassen",
      value: classes.length,
      icon: Users,
      color: "indigo",
    },
    {
      title: "Totaal Studenten",
      value: classes.reduce((sum, c) => sum + (c.student_count || 0), 0),
      icon: Users,
      color: "blue",
    },
    {
      title: "Waarschuwingen Deze Week",
      value: 0,
      icon: Zap,
      color: "orange",
    },
    {
      title: "Gem. Schermtijd (min/dag)",
      value: 0,
      icon: Clock,
      color: "red",
    },
  ];

  return (
    <div className="space-y-8 p-8 bg-slate-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500 mt-2">Welkom terug, Docent!</p>
        </div>
        <Button
          onClick={() => createClassMutation.mutate()}
          className="bg-indigo-600 hover:bg-indigo-700 text-white"
          disabled={creating}
        >
          <Plus className="w-4 h-4 mr-2" />
          Nieuwe Klas
        </Button>
      </div>

      {/* Statistieken */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Klassenlijst */}
      <Card className="border-slate-100">
        <CardHeader>
          <CardTitle>Mijn Klassen</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              <p className="text-slate-500">Bezig met laden...</p>
            ) : classes.length > 0 ? (
              classes.map((cls) => (
                <div
                  key={cls.id}
                  className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <div>
                    <h3 className="font-semibold text-slate-900">
                      {cls.name || "Naamloze Klas"}
                    </h3>
                    <p className="text-sm text-slate-500">
                      {cls.description || "Geen beschrijving"}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Beheren
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-slate-500 text-center py-8">
                Geen klassen gevonden. Maak een nieuwe klas aan!
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Debug sectie */}
      <Card className="border-slate-200 mt-8">
        <CardHeader>
          <CardTitle>Debug Klassen State</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-slate-100 p-4 rounded text-sm overflow-x-auto">
            {JSON.stringify(classes, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}
