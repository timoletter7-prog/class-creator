import React from 'react';
import { Shield, Clock, Trophy, Flame, Lock } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import StatCard from './StatCard';
import { Button } from "@/components/ui/button";

export default function StudentDashboard({ stats, profile }) {
  const usagePercent = stats?.usage_percent || 0;
  const points = profile?.points !== undefined ? profile.points : 10;
  const streak = profile?.streak_days || 0;
  const screenTime = stats?.screen_time_minutes || 0;

  const formatTime = (mins) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h > 0 ? `${h}u ${m}m` : `${m}m`;
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Hoi {profile?.full_name?.split(' ')[0] || 'Student'}! 👋</h1>
        <p className="text-slate-500">Welkom op je dashboard. Hier zie je hoe je ervoor staat.</p>
      </div>

      {/* Hero Points Section */}
      <div className="bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl p-6 md:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 bg-white/10 w-64 h-64 rounded-full -mr-16 -mt-16 blur-3xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="text-indigo-100 font-medium mb-1">Jouw Score</p>
            <div className="flex items-baseline gap-2">
              <span className="text-5xl font-bold">{points}</span>
              <span className="text-xl text-indigo-200">punten</span>
            </div>
            <p className="text-sm text-indigo-200 mt-2 max-w-md">
              {points < 10 
                ? "Probeer vandaag geen waarschuwingen te krijgen om weer omhoog te gaan!" 
                : "Je bent goed bezig! Blijf zo doorgaan voor extra beloningen."}
            </p>
          </div>
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
             <div className="p-3 bg-orange-500/20 rounded-lg text-orange-300">
               <Flame className="w-8 h-8" />
             </div>
             <div>
               <p className="text-2xl font-bold">{streak}</p>
               <p className="text-xs text-indigo-200 uppercase tracking-wider font-semibold">Dagen Reeks</p>
             </div>
          </div>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-slate-100 shadow-sm">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm text-slate-500 font-medium">Schermtijd Vandaag</p>
                <h3 className="text-2xl font-bold mt-1">{formatTime(screenTime)}</h3>
              </div>
              <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                <Clock className="w-5 h-5" />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-500">
                <span>Gebruikt</span>
                <span>{Math.round(usagePercent)}% van limiet</span>
              </div>
              <Progress value={usagePercent} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-100 shadow-sm">
           <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm text-slate-500 font-medium">App Status</p>
                <h3 className="text-2xl font-bold mt-1 text-emerald-600">Actief</h3>
              </div>
              <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
                <Shield className="w-5 h-5" />
              </div>
            </div>
            <p className="text-sm text-slate-500">Je whitelisted apps zijn beschikbaar.</p>
          </CardContent>
        </Card>

        <Card className="border-slate-100 shadow-sm">
           <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm text-slate-500 font-medium">Volgende Beloning</p>
                <h3 className="text-2xl font-bold mt-1">+0.5 Punt</h3>
              </div>
              <div className="p-2 bg-yellow-50 rounded-lg text-yellow-600">
                <Trophy className="w-5 h-5" />
              </div>
            </div>
            <p className="text-sm text-slate-500">Bonus op de toets bij 30 dagen reeks.</p>
          </CardContent>
        </Card>
      </div>

      {/* Blocked Apps Visualization */}
      <Card className="border-slate-100 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">App Blokkades</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['TikTok', 'Snapchat', 'Instagram', 'Games'].map((app) => (
              <div key={app} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 border border-slate-100 opacity-60">
                <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center">
                  <Lock className="w-5 h-5 text-slate-400" />
                </div>
                <span className="font-medium text-slate-600">{app}</span>
              </div>
            ))}
          </div>
          <div className="mt-6 p-4 bg-indigo-50 rounded-xl flex items-center justify-between">
             <div>
               <h4 className="font-semibold text-indigo-900">
                 {stats?.time_remaining ? `Nog ${formatTime(stats.time_remaining)} over` : "Voldoende tijd over"}
               </h4>
               <p className="text-sm text-indigo-600">Daarna worden alle niet-essentiële apps geblokkeerd.</p>
             </div>
             <Button variant="outline" className="border-indigo-200 text-indigo-700 hover:bg-indigo-100">
               Bekijk Whitelist
             </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
