import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Layout from "./Layout";

// Supabase-aware TeacherDashboard
import TeacherDashboard from "./components/dashboard/TeacherDashboard";
import Classes from "./pages/Classes";
import Goals from "./pages/Goals";
import Settings from "./pages/Settings";
import Whitelist from "./pages/Whitelist";

// Wrapper zodat we de user uit AuthContext kunnen doorgeven
function TeacherDashboardWrapper() {
  const { user } = useAuth();
  return <TeacherDashboard user={user} />;
}

export default function App() {
  return (
    <AuthProvider>
      <Toaster position="top-right" richColors />
      <Layout>
        <Routes>
          {/* Dashboard met Supabase */}
          <Route path="/" element={<TeacherDashboardWrapper />} />

          {/* Overige pagina's */}
          <Route path="/classes" element={<Classes />} />
          <Route path="/goals" element={<Goals />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/whitelist" element={<Whitelist />} />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </AuthProvider>
  );
}
